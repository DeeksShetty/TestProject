<?php

namespace Tests\Feature;

use App\Models\User;
use Faker\Factory;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class UserTest extends TestCase
{
    /**
     * A basic feature test example.
     *
     * @return void
     */
    // public function test_register_user(){
    //     $formData = [
    //         'email'=>'test@mail.com',
    //         'password'=>'123456',
    //         'password_confirmation'=>'123456',
    //         'phone'=>'2154875458'];
    //     $this->post('/api/register',$formData)->assertStatus(200);

    // }
    // public function test_login_user(){
    //     $formData = [
    //         'email'=>'test@mail.com',
    //         'password'=>'123456'];
    //     $this->post('/api/login',$formData)->assertStatus(200);

    // }

    public function test_update_user(){
        // $user= factory(User::class)->create();

        $formData = [
            'first_name'=>'test@mail.com',
            'last_name'=>'123456',
            'role'=>'writer'];
        $this->post('/api/update-profile',$formData)->assertStatus(200);

    }

}
